from django.urls import path
from .views import custom_logout
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # Make login the default route
    path('', auth_views.LoginView.as_view(
        template_name='login.html',
          extra_context={'hide_nav': True, 'hide_sidebar': True},
        redirect_authenticated_user=True  # Always show the login form
    ), name='login'),

    path('register/', views.register, name='register'),
    
    path('home/', views.home, name='home'),

    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('modules/', views.modules_list, name='modules_list'),
    path('logout/', custom_logout, name='logout'),
    path('module/<int:module_id>/register/', views.register_module, name='register_module'),
    path('module/<int:module_id>/unregister/', views.unregister_module, name='unregister_module'),
]
