from django.db import models
from django.contrib.auth.models import User, Group

class Module(models.Model):
    AVAILABILITY_CHOICES = (
        ('open', 'Open'),
        ('closed', 'Closed'),
    )
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20, unique=True)
    credit = models.IntegerField()
    category = models.CharField(max_length=50)
    description = models.TextField()
    availability = models.CharField(max_length=6, choices=AVAILABILITY_CHOICES, default='open')
    courses_allowed = models.ManyToManyField(Group, related_name="modules")

    def __str__(self):
        return self.name

class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    date_of_birth = models.DateField()
    address = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    country = models.CharField(max_length=100)
    photo = models.ImageField(upload_to='student_photos/')

    def __str__(self):
        return self.user.username

class Registration(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    module = models.ForeignKey(Module, on_delete=models.CASCADE)
    date_of_registration = models.DateField(auto_now_add=True)

    class Meta:
        unique_together = ('student', 'module')

    def __str__(self):
        return f"{self.student.user.username} - {self.module.code}"
