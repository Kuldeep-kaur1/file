# core/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Student

class StudentRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    date_of_birth = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        label="Date of Birth"
    )
    address = forms.CharField(max_length=255, label="Address")
    city = forms.CharField(max_length=100, label="City/Town")
    country = forms.CharField(max_length=100, label="Country")
    photo = forms.ImageField(required=False, label="Photo")

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 
                  'date_of_birth', 'address', 'city', 'country', 'photo')

    def save(self, commit=True):
        user = super().save(commit=commit)
        Student.objects.create(
            user=user,
            date_of_birth=self.cleaned_data['date_of_birth'],
            address=self.cleaned_data['address'],
            city=self.cleaned_data['city'],
            country=self.cleaned_data['country'],
            photo=self.cleaned_data.get('photo')  # May be None if not uploaded
        )
        return user
