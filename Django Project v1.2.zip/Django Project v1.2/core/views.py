from django.shortcuts import render
from django.core.paginator import Paginator
from .models import Module, Registration, Student
from django.shortcuts import redirect
from django.contrib.auth import logout
from django.shortcuts import render, redirect
from .forms import StudentRegistrationForm
from django.shortcuts import redirect, get_object_or_404
from django.contrib.auth.decorators import login_required


def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

def modules_list(request):
    # Fetch all modules, ordered by code
    modules_qs = Module.objects.all().order_by('code')

    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        modules_qs = modules_qs.filter(name__icontains=search_query)

    # Get the page size from query parameters (default to 5)
    page_size = request.GET.get('page_size', 5)
    try:
        page_size = int(page_size)
    except ValueError:
        page_size = 5

    # Set up pagination
    paginator = Paginator(modules_qs, page_size)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Build extra context for registered modules
    my_module_ids = []
    my_modules = []
    if request.user.is_authenticated:
        try:
            student = request.user.student  # Assumes a OneToOne relation from User to Student
            regs = Registration.objects.filter(student=student)
            # Get a list of module IDs already registered
            my_module_ids = list(regs.values_list('module_id', flat=True))
            # Build a list of Module objects for "My Modules" tab
            my_modules = [reg.module for reg in regs]
        except Student.DoesNotExist:
            my_module_ids = []
            my_modules = []

    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'page_size': page_size,
        'my_module_ids': my_module_ids,
        'my_modules': my_modules,
    }
    return render(request, 'modules_list.html', context)

def custom_logout(request):
    # Log the user out
    logout(request)
    # Redirect to root
    return redirect('/')

def register(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = StudentRegistrationForm()
    
    # Pass hide_sidebar=True so the user doesn't see the side menu
    return render(request, 'register.html', {
        'form': form,
        'hide_sidebar': True
    })

@login_required
def register_module(request, module_id):
    module = get_object_or_404(Module, id=module_id)
    student = request.user.student  # Assumes a OneToOne relation from User to Student
    # Create a registration if it doesn't exist
    Registration.objects.get_or_create(student=student, module=module)
    return redirect('modules_list')

@login_required
def unregister_module(request, module_id):
    module = get_object_or_404(Module, id=module_id)
    student = request.user.student
    # Delete the registration if it exists
    Registration.objects.filter(student=student, module=module).delete()
    return redirect('modules_list')

