# University Registration Portal

This is a Django-based web application that enables students to register and unregister for modules offered under their course. The project follows the Model-View-Controller (MVC) paradigm and uses Bootstrap for a modern, responsive design.

## Features

- **Home:** Landing page with navigation and course overview.
- **About Us:** Information about the university.
- **Contact Us:** A contact form for inquiries.
- **List of Modules:** Displays available modules with details and registration actions.
- Uses Django’s built-in User and Group models.
- Custom models for **Module**, **Student**, and **Registration**.
- Uses SQLite as the default database.
- Uses Pillow for image handling in the Student model.
- Integrated Bootstrap via CDN for styling.

## Prerequisites

- **Python 3.x** (Download from [python.org](https://www.python.org/downloads/))
- **Visual Studio Code** or your preferred code editor

## Installation and Setup

### 1. Clone the Repository

If you are using Git, run the following command:
git clone <repository_url>
cd danjo_project

2. Create and Activate a Virtual Environment
On Windows:
python -m venv env
env\Scripts\activate

On macOS/Linux:
python3 -m venv env
source env/bin/activate

3. Install Required Packages
Install Django and Pillow (along with any other dependencies):

pip install django Pillow

4. Apply Migrations
Generate and apply migrations to set up your database schema:

python manage.py makemigrations
python manage.py migrate

5. Create a Superuser

Create an admin account to access the Django admin panel:

python manage.py createsuperuser


Running the Project
1. Start the Development Server
Launch the server with:

python manage.py runserver

2. Access the Application

Open your browser and navigate to http://127.0.0.1:8000/ to view the landing page.

Access the admin panel at http://127.0.0.1:8000/admin/ using your superuser credentials.

Project Structure

project layout should look like the following:

danjo_project/
├── core/
│   ├── migrations/
│   ├── admin.py
│   ├── apps.py
│   ├── models.py
│   ├── tests.py
│   ├── urls.py
│   └── views.py
├── danjo/
│   ├── __init__.py
│   ├── asgi.py
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── templates/
│   ├── base.html
│   ├── home.html
│   ├── about.html
│   ├── contact.html
│   └── modules_list.html
├── static/
│   └── css/
│       └── style.css
├── env/           # Virtual environment folder
├── manage.py
└── db.sqlite3     # SQLite database file (generated after migrations)

Templates & Styling
Bootstrap Integration

The project uses the Bootstrap 5 CDN to style components. The updated base.html includes links to Bootstrap CSS and the JS bundle.

Custom CSS

Additional styles can be added or overridden in static/css/style.css.

Customization

Extend Functionality
The groundwork includes basic models, views, and templates. You can extend this with custom forms, validations, and business logic to enable student module registrations.

