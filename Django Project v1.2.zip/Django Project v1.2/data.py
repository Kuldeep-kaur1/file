from core.models import Module

# Example data
modules_data = [
    {
        'name': 'ACADEMIC STUDY SKILLS',
        'code': 'SEM1-AS-20245',
        'credit': 10,
        'category': 'General',
        'description': 'Introduction to academic writing, referencing, and study skills.',
        'availability': 'open'
    },
    {
        'name': 'CORPORATE GOVERNANCE AND ETHICS',
        'code': 'SEM2-CG-20245',
        'credit': 15,
        'category': 'Business',
        'description': 'Explores corporate governance frameworks, ethical decision-making, and compliance.',
        'availability': 'open'
    },
    {
        'name': 'DISSERTATION OR APPLIED BUSINESS PROJECT',
        'code': 'CONT-DB-20245',
        'credit': 30,
        'category': 'Research',
        'description': 'Focus on independent research or real-world business projects with academic supervision.',
        'availability': 'closed'
    },
    {
        'name': 'Corporate Governance And Ethics',
        'code': '44-700637-AF-20245',
        'credit': 15,
        'category': 'Business',
        'description': 'Focus on corporate governance frameworks, ethical decision-making, and compliance.',
        'availability': 'open'
    },
    {
        'name': 'Dissertation Or Applied Business Project',
        'code': '44-700636-AF-20245',
        'credit': 30,
        'category': 'Research',
        'description': 'Independent research or real-world business project with academic supervision.',
        'availability': 'open'
    },
    {
        'name': 'Employability And Study Skills',
        'code': '44-700342-AF-20245',
        'credit': 10,
        'category': 'General',
        'description': 'Enhances employability skills, academic writing, referencing, and personal development.',
        'availability': 'open'
    },
    {
        'name': 'Finance',
        'code': '44-700356-AF-20245',
        'credit': 15,
        'category': 'Finance',
        'description': 'Explores fundamental finance principles, capital budgeting, and financial statements.',
        'availability': 'open'
    },
    {
        'name': 'Financial Management And Risk Management',
        'code': '44-701524-AF-20245',
        'credit': 20,
        'category': 'Finance',
        'description': 'Advanced topics in corporate finance, risk analysis, and financial strategy.',
        'availability': 'open'
    },
    {
        'name': 'Mergers And Acquisitions',
        'code': '44-700437-AF-20245',
        'credit': 15,
        'category': 'Business',
        'description': 'Examines the strategic and financial aspects of M&A deals, including due diligence.',
        'availability': 'open'
    },
    {
        'name': 'Strategic Management Accounting For Performance Management',
        'code': '44-701534-AF-20245',
        'credit': 15,
        'category': 'Accounting',
        'description': 'Focus on performance measurement, budgeting, and cost management for strategic decision-making.',
        'availability': 'open'
    }
]

for mod in modules_data:
    Module.objects.create(**mod)

print("Modules inserted successfully!")
